<div style="height:3vh;width:100%;color:#7e7e7e;background-color:#fff;font-weight:bolder;margin:0;margin-top:1vw;">
    <center><a href="about.php">About</a>&nbsp;&nbsp;Copyrigth&copy;:2019</center>
</div>